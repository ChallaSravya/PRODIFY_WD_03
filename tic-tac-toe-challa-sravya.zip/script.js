const cells = document.querySelectorAll("[data-cell]");
const message = document.getElementById("message");
const resultText = document.getElementById("resultText");

let isOturn = false;

const winCombos = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

function startGame() {
  isOturn = false;
  message.style.display = "none";
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("X", "O");
    cell.addEventListener("click", handleClick, { once: true });
  });
}

function handleClick(e) {
  const cell = e.target;
  const currentClass = isOturn ? "O" : "X";
  cell.textContent = currentClass;
  cell.classList.add(currentClass);

  if (checkWin(currentClass)) {
    endGame(false);
  } else if (isDraw()) {
    endGame(true);
  } else {
    isOturn = !isOturn;
  }
}

function endGame(draw) {
  if (draw) {
    resultText.textContent = "It's a Draw!";
  } else {
    resultText.textContent = \`\${isOturn ? "O" : "X"} Wins!\`;
  }
  message.style.display = "block";
}

function isDraw() {
  return [...cells].every(cell => cell.textContent === "X" || cell.textContent === "O");
}

function checkWin(currentClass) {
  return winCombos.some(combo => {
    return combo.every(index => {
      return cells[index].classList.contains(currentClass);
    });
  });
}

startGame();
